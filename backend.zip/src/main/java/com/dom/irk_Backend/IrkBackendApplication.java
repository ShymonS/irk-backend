package com.dom.irk_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class IrkBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(IrkBackendApplication.class, args);
    }

}